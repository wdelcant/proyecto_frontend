const elements = [
  {
    title: 'Lorem Ipsum',
    subtitle: 'Ipsum',
    image: '../public/images/4.jpg',
    text: 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock,'
  },
  {
    title: 'Ipsum Second',
    subtitle: 'Lorem',
    image: '../public/images/3.jpg',
    text: 'Making it over 2000 years old. Richard McClintock,'
  },
  {
    title: 'Ipsum Second',
    subtitle: 'Lorem',
    image: '../public/images/5.jpg',
    text: 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis'
  },
  {
    title: 'Ipsum Second',
    subtitle: 'Lorem',
    image: '../public/images/6.jpg',
    text: 'On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail '
  }
];

export default elements;
